
$('#loging').animate({display:'none'},2000);

let menuBtn=$('#header>.header-top>.container>span>.menu-btn');
let menuList=$('#menu');

menuList.hide();
menuBtn.click(function(){
    let a=true;
    if(a==true){
        menuList.show();
    }else{
        menuList.hide();
    }
});

let loginBtn=$('.login-inner>button');

loginBtn.click(function(){
    location.href="./mypage.html"
})